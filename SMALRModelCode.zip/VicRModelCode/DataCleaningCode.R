
DataCleaningModel <- function(dataset) {

#install.packages("twitteR")
#install.packages("plyr")
#install.packages("stringr")
#install.packages(tm)

#loading the library
library(twitteR)
library(plyr)
library(stringr)
library(ggplot2)
library(tm)


  Dataset2 <- read.csv(dataset)
  tweets.df <- Dataset2$Text


#tweets.df<-file$text
tweets.df<-tolower(tweets.df)

#for Windows based OS
tweets.df <- sapply(tweets.df,function(row) iconv(row, "latin1", "ASCII", sub=""))

#common for any platform
tweets.df = gsub("&amp", "", tweets.df)
tweets.df= gsub("(RT|via)((?:\\b\\W*@\\w+)+)", "", tweets.df)
tweets.df = gsub("@\\w+", "", tweets.df)
tweets.df= gsub("[[:punct:]]", "", tweets.df)
tweets.df = gsub("[[:digit:]]", "", tweets.df)
tweets.df = gsub("http\\w+", "", tweets.df)
tweets.df = gsub("[ \t]{2,}", "", tweets.df)
tweets.df= gsub("^\\s+|\\s+$", "", tweets.df) 
#ref: ( Hicks , 2014) After the above I did the below.

#get rid of unnecessary spaces
tweets.df <- str_replace_all(tweets.df," "," ")
# Get rid of URLs
#tweets.df <- str_replace_all(tweets.df, "http://t.co/[a-z,A-Z,0-9]*{8}","")
# Take out retweet header, there is only one
tweets.df <- str_replace(tweets.df,"RT @[a-z,A-Z]*: ","")
# Get rid of hashtags
tweets.df <- str_replace_all(tweets.df,"#[a-z,A-Z]*","")
# Get rid of references to other screennames
tweets.df <- str_replace_all(tweets.df,"@[a-z,A-Z]*","")  

View(tweets.df)

}

#DataCleaningModel("C:/Users/gikoro/Downloads/SmalRmodules/SmalRmodules/dataset2.csv")


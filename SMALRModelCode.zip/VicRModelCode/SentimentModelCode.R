#install.packages("twitteR")
#install.packages("plyr")
#install.packages("stringr")
#install.packages("tm")
#install.packages("scales")


Sentiment <- function(dataset,positive_words,negative_words) {


#loading the library
library(twitteR)
library(plyr)
library(stringr)
library(ggplot2)
library(tm)
library(scales)



filed <-read.csv(dataset)
tweets.df<-filed$Text
tweets.df<-tolower(tweets.df)

#for Windows based OS
tweets.df <- sapply(tweets.df,function(row) iconv(row, "latin1", "ASCII", sub=""))

#common for any platform
tweets.df = gsub("&amp", "", tweets.df)
tweets.df= gsub("(RT|via)((?:\\b\\W*@\\w+)+)", "", tweets.df)
tweets.df = gsub("@\\w+", "", tweets.df)
tweets.df= gsub("[[:punct:]]", "", tweets.df)
tweets.df = gsub("[[:digit:]]", "", tweets.df)
tweets.df = gsub("http\\w+", "", tweets.df)
tweets.df = gsub("[ \t]{2,}", "", tweets.df)
tweets.df= gsub("^\\s+|\\s+$", "", tweets.df) 
#ref: ( Hicks , 2014) After the above I did the below.

#get rid of unnecessary spaces
tweets.df <- str_replace_all(tweets.df," "," ")
# Get rid of URLs
#tweets.df <- str_replace_all(tweets.df, "http://t.co/[a-z,A-Z,0-9]*{8}","")
# Take out retweet header, there is only one
tweets.df <- str_replace(tweets.df,"RT @[a-z,A-Z]*: ","")
# Get rid of hashtags
tweets.df <- str_replace_all(tweets.df,"#[a-z,A-Z]*","")
# Get rid of references to other screennames
tweets.df <- str_replace_all(tweets.df,"@[a-z,A-Z]*","")  

View(tweets.df)


#Reading the Lexicon positive and negative words
pos <- readLines(positive_words)
neg <- readLines(negative_words)

#function to calculate sentiment score
score.sentiment <- function(sentences, pos.words, neg.words, .progress='none')
{
  # Parameters
  # sentences: vector of text to score
  # pos.words: vector of words of postive sentiment
  # neg.words: vector of words of negative sentiment
  # .progress: passed to laply() to control of progress bar
  
  # create simple array of scores with laply
  scores <- laply(sentences,
                  function(sentence, pos.words, neg.words)
                  {
                    # remove punctuation
                    sentence <- gsub("[[:punct:]]", "", sentence)
                    # remove control characters
                    sentence <- gsub("[[:cntrl:]]", "", sentence)
                    # remove digits
                    sentence <- gsub('\\d+', '', sentence)
                    
                    #convert to lower
                    sentence <- tolower(sentence)
                    
                    
                    # split sentence into words with str_split (stringr package)
                    word.list <- str_split(sentence, "\\s+")
                    words <- unlist(word.list)
                    
                    # compare words to the dictionaries of positive & negative terms
                    pos.matches <- match(words, pos)
                    neg.matches <- match(words, neg)
                    
                    # get the position of the matched term or NA
                    # we just want a TRUE/FALSE
                    pos.matches <- !is.na(pos.matches)
                    neg.matches <- !is.na(neg.matches)
                    
                    # final score
                    score <- sum(pos.matches) - sum(neg.matches)
                    return(score)
                  }, pos.words, neg.words, .progress=.progress )
  # data frame with scores for each sentence
  scores.df <- data.frame(text=sentences, score=scores)
  return(scores.df)
}
#sentiment score
scores_twitter <- score.sentiment(tweets.df, pos, neg, .progress='text')

#scores_twitter <- score.sentiment(sentPN$tweets.df, pos, neg, .progress='text')
View(scores_twitter)

#Summary of the sentiment scores
summary(scores_twitter)

#Convert sentiment scores from numeric to character to enable the gsub function 
#scores_twitter$score_chr <- as.character(scores_twitter$score)

scores_twitter$score_chr <- ifelse(scores_twitter$score < 0,'Negtive', ifelse(scores_twitter$score > 0, 'Positive', 'Neutral'))

#After looking at the summary(scores_twitter$score) decide on a threshold for the sentiment labels
#scores_twitter$score_chr <- gsub("^0$", "Neutral", scores_twitter$score_chr)
#scores_twitter$score_chr <- gsub("^1$|^2$|^3$|^4$", "Positive", scores_twitter$score_chr)
#scores_twitter$score_chr <- gsub("^5$|^6$|^7$|^8$|^9$|^10$|^11$|^12$", "Very Positive", scores_twitter$score_chr)
#scores_twitter$score_chr <- gsub("^-1$|^-2$|^-3$|^-4$", "Negative", scores_twitter$score_chr)
#scores_twitter$score_chr <- gsub("^-5$|^-6$|^-7$|^-8$|^-9$|^-10$|^-11$|^-12$|^-13$", "Very Negative", scores_twitter$score_chr)
#scores_twitter$score_chr <- gsub("<-5$", "Very Negative", scores_twitter$score_chr)

View(scores_twitter)


#Convert score_chr to factor for visualizations
scores_twitter$score_chr <- as.factor(scores_twitter$score_chr)
names(scores_twitter)[3]<-paste("Sentiment")  # works
require(scales)
#plot to show number of negative, positive and neutral comments
Viz1 <- ggplot(scores_twitter, aes(x=Sentiment, fill=Sentiment))+ geom_bar(aes(y = (..count..)/sum(..count..))) + 
  scale_y_continuous(labels = percent)+labs(y="Score")+
  theme(text =element_text(size=15))+theme(axis.text = element_text(size=15))+ theme(legend.position="none")+ coord_cartesian(ylim=c(0,0.6)) + scale_fill_manual(values=c("firebrick1", "grey50", "limeGREEN"))


return(Viz1)
#writing to csv file
#write.csv(scores_twitter, file = "Britishenergysent_score.csv")
}

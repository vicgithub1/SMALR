

SearchKeyWordModel <- function(consumerKey,consumerSecret,accessToken,accessSecret,n,SearchKeyWord){
  
  install.packages("twitteR")
  install.packages("ROAuth")
  library(twitteR)
  library(ROAuth)
  
  consumerKey <-	consumerKey
  #"sy5KZZej84vrYy4bzQ2sYpmR0"
  consumerSecret<- consumerSecret
  #"00phcX4EvvoxHIFJTk4bAv74hehiQT6h6sQXuW4PiNjfoRTb40"
  
  accessToken<- accessToken
  #"974511175806234624-Lwib38TD7IpbOhiYmH4KsmK4pBkQE4p"
  
  accessSecret<- accessSecret
  #"GHm92QCaJjDrEWVSFSLYTALXsl83XrQMDEfaH7Tnmfs5w"
  
  setup_twitter_oauth (consumerKey, consumerSecret, accessToken, accessSecret)  # authenticate
  
  

tweets<-searchTwitter("SearchKeyWord", n=n, lang=NULL, since=NULL, until=NULL, locale=NULL, geocode=NULL, sinceID=NULL, maxID=NULL,
                                resultType=NULL, retryOnRateLimit=120)

#Put the tweets in a data frame
tweets<-twListToDF(tweets)
write.csv(tweets, file="tweets.csv")

return(tweets)

}



KeyWordSearched <- SearchKeyWordModel("sy5KZZej84vrYy4bzQ2sYpmR0","00phcX4EvvoxHIFJTk4bAv74hehiQT6h6sQXuW4PiNjfoRTb40","974511175806234624-Lwib38TD7IpbOhiYmH4KsmK4pBkQE4p","GHm92QCaJjDrEWVSFSLYTALXsl83XrQMDEfaH7Tnmfs5w",500,trump)


#consumerKey<-	"sy5KZZej84vrYy4bzQ2sYpmR0"
#consumerSecret<-"00phcX4EvvoxHIFJTk4bAv74hehiQT6h6sQXuW4PiNjfoRTb40"

#accessToken<-"974511175806234624-Lwib38TD7IpbOhiYmH4KsmK4pBkQE4p"
#accessSecret<-"GHm92QCaJjDrEWVSFSLYTALXsl83XrQMDEfaH7Tnmfs5w"

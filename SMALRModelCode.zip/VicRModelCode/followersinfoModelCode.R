
followersinfoModel <- function(consumerKey,consumersecret,n,UserAccount) {

 #install.packages("rtweet")#install rtweet if not alredy installed
 library(rtweet)

#insert the consumer key and consumer secret from twitter
#create_token(
  
  consumer_key = consumerKey
    #"OwtXACDeqYmmgFkTXsZO8pWtp"
  consumer_secret = consumersecret
    #"5Ke0wVfmoRNXsp3aeq3nFOiExH8GynRAZUdfa0i4VznsSdO6py"
#)
followers<- get_followers(UserAccount, n = 1000, page = "-1", retryonratelimit = FALSE,
              parse = TRUE, verbose = TRUE, token = NULL) #get the ID list of followers ID list of 
count<-nrow(followers)#number of followers
followersinfo<-lookup_users(followers$user_id)

#write.csv(followers, file="followers.csv")
#write.csv(followersinfo, file="followersinfo.csv")

return(followersinfo)

}
 

followersinfo4 <- followersinfoModel("OwtXACDeqYmmgFkTXsZO8pWtp","5Ke0wVfmoRNXsp3aeq3nFOiExH8GynRAZUdfa0i4VznsSdO6py",1000,"skynews")

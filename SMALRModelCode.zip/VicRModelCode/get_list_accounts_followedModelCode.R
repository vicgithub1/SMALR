UoM_fds_dataModel <- function(consumerKey,consumersecret,UserAccount) {

    #install.packages("rtweet")#install rtweet if not alredy installed
     library(rtweet)

   #insert the consumer key and consumer secret from twitter

  consumer_key = consumerKey
  
  consumer_secret = consumersecret
  
   UoM_fds <- get_friends(UserAccount)# get list of accounts followed by the University of manchester official twitter account

## lookup data on those accounts:name, location, language, etc.
   UoM_fds_data <- lookup_users(UoM_fds$user_id)

    return(UoM_fds_data)

}



UoM_fds_data <- UoM_fds_dataModel("OwtXACDeqYmmgFkTXsZO8pWtp","5Ke0wVfmoRNXsp3aeq3nFOiExH8GynRAZUdfa0i4VznsSdO6py","officialUoM")


TimelineModel <- function(consumerKey,consumer_secret,n,Timeline) {
  
  
  #install.packages("rtweet")#install rtweet if not alredy installed
  library(rtweet)
  
  timeline<-get_timeline(Timeline,n=200)  #replace cnn with the twitter user username 

  #timelines<-get_timelines(c("cnn","trump"), n=200)#to get multiple users timeline

  return(timeline)

}

#TimelineModel <- TimelineModel("OwtXACDeqYmmgFkTXsZO8pWtp","5Ke0wVfmoRNXsp3aeq3nFOiExH8GynRAZUdfa0i4VznsSdO6py",200,"trump")
